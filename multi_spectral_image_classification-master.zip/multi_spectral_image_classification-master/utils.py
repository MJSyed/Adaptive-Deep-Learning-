import numpy as np
import pandas as pd
import tensorflow as tf

def crop_center(img,cropx,cropy):
    """
    Returns center croped image
    """
    y,x = img.shape
    startx = x//2-(cropx//2)
    starty = y//2-(cropy//2)    
    return img[starty:starty+cropy,startx:startx+cropx]

def crop_resize(images, crop_dim, resize_dim):
    """
    Return an image that is center cropped and then resized
    """
    ### NB: This is where the pixels are inverted "1 -images......."
    imgs = np.array([np.flip(crop_center(1-images[i].reshape((350, 350)).T, crop_dim, crop_dim), axis=1) for i in range(len(images))])
    imgs = imgs.reshape((imgs.shape[0],crop_dim,crop_dim ,1))
    imgs = tf.image.resize(imgs, (resize_dim,resize_dim))    
    return imgs


def generator(features, labels, batch_size):
    """
    Python Generator for generating batches in for the model
    """
    for i in range(0, len(features), batch_size):
        yield (features[i:i+batch_size], labels[i:i+batch_size])

def load_models(models):
    """
    Returns a dictionary of models availible
    args:
        models: A list of intergers indicating the which models to load 
    """
    model_dict = {}
    for i in models:
        from tensorflow.keras.models import model_from_json
        json_file = open('Models/model{}_json.json'.format(i), 'r')
        loaded_model_json = json_file.read()
        json_file.close()
        model = model_from_json(loaded_model_json)
        model.load_weights("Models/model{}.h5".format(i))
        model_dict.update({"channel{}".format(i): model})
    return model_dict

def load_channels(channels):
    """
    Returns a dictionary with data for each channel
    args: A list of  integers representing each channel
    NB: Test data only, doesnt load labels
    """
    chan_dict = {}
    for i in channels:
        tmp = np.load("channels/channel_{}_xtest.npy".format(i))
        chan_dict.update({"channel{}".format(i): crop_resize(tmp, 140, 50).numpy() })
    return chan_dict
